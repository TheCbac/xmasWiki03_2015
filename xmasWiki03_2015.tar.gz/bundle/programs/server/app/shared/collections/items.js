(function(){items = new Meteor.Collection('Items');
}).call(this);

//# sourceMappingURL=items.js.map
