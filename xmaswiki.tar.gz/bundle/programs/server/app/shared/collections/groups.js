(function(){Groups = new Meteor.Collection('groups');
}).call(this);

//# sourceMappingURL=groups.js.map
